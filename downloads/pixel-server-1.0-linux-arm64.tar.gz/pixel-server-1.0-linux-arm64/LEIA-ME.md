# Pixel Server para Linux, NAS e Windows

O Pixel Server grava programas de TV para a app **Pixel IPTV**. Programas a gravação na app. O servidor grava e guarda, e todos os iPhone, iPad e Apple TV de casa veem a partir dele.

No Mac, o Pixel Server é uma app na barra de menus. Esta pasta trata de todas as outras máquinas:

| Onde | Como | Ficheiro |
|---|---|---|
| PC ou servidor Linux, NAS (Synology, QNAP, Unraid…) | Docker | `compose.linux.yml` |
| PC com Windows 10 ou 11 | instalador (um serviço do Windows) | `PixelServer-<versão>-windows-<arq>.exe` — ver `Windows/INSTALAR.md` |
| PC com Windows (ou um Mac sem a app do Mac) | Docker Desktop | `compose.desktop.yml` |
| Linux sem Docker | serviço do systemd | `pixel-server-<versão>-linux-<arq>.tar.gz` |

A máquina tem de estar ligada quando uma gravação começa. O servidor funciona só na **rede de casa** (ver [Fora de casa](#fora-de-casa)).

Há uma versão em inglês deste guia em [README.md](README.md).

---

## A imagem

Enquanto a imagem não estiver publicada, cria-a a partir da pasta `PixelServer` (a que contém `Docker/`):

```sh
docker build -f Docker/Dockerfile -t pixel-server:latest .
```

Para criar a imagem é preciso o BuildKit, que o Docker usa por omissão desde a versão 23 (a primeira linha do Dockerfile vai buscar a sintaxe de Dockerfile de que precisa, por isso uma mais antiga incluída no Docker serve). Os ficheiros compose também a podem criar (`docker compose -f Docker/compose.linux.yml build`). A imagem serve para `linux/amd64` (Intel e AMD) e `linux/arm64` (Raspberry Pi 4/5, a maioria dos NAS ARM). Traz o servidor e o seu próprio FFmpeg, que o servidor usa para as imagens das Cenas e, em `amd64`, para as versões leves numa GPU (vê [Versões leves numa GPU](#versões-leves-numa-gpu)).

## Docker no Linux ou num NAS

1. Copia o `compose.linux.yml` para uma pasta só dele, por exemplo `~/pixel-server`.
2. Edita-o:
   - **`PUID` / `PGID`**: o utilizador e o grupo com que o servidor corre. Usa os do dono da pasta das gravações (corre `id` como esse utilizador). Num Synology, usa os do teu utilizador (`id` por SSH).
   - **`TZ`**: o teu fuso horário, para o registo mostrar as horas locais.
   - **`volumes`**: `/config` guarda a lista das gravações, os aparelhos emparelhados e a palavra-passe da página de gestão. Mantém-na num **disco local**, nunca numa partilha de rede (CIFS/SMB, NFS): aí não funciona o bloqueio que impede dois servidores de gravarem o mesmo programa. `/recordings` pode ser qualquer pasta, incluindo uma partilha do NAS.
3. Arranca-o:

   ```sh
   docker compose -f compose.linux.yml up -d
   ```

O ficheiro usa `network_mode: host`, para o servidor ver o endereço da rede de casa e a app o encontrar aí. Com a rede bridge do Docker, o servidor só vê os endereços do próprio Docker (172.17.x.x). Se tiveres mesmo de usar uma bridge, faz como no Docker Desktop: publica a porta só em IPv4 (`"0.0.0.0:8790:8790"`) e define `PIXEL_ADDRESSES`. Numa bridge, o Docker entrega ao servidor todas as ligações a partir do seu próprio endereço, por isso a página de gestão não distingue um cliente em casa de um de fora: só a palavra-passe a protege (a página di-lo).

**Notas para NAS**
- **Synology** (Container Manager): *Projeto → Criar*, cola o `compose.linux.yml` e aponta os volumes para pastas em `/volume1/docker/pixel-server/…`.
- **QNAP** (Container Station): *Aplicações → Criar* com o mesmo ficheiro.
- **Unraid**: usa o plugin Compose Manager com o mesmo ficheiro. `PUID=99` e `PGID=100` são o dono habitual das partilhas no Unraid.

O servidor nunca corre como root. Ao arrancar, dá ao `PUID:PGID` as pastas `/config` e `/recordings` (só as pastas, não os ficheiros dentro de `/recordings`) se esse utilizador não puder escrever nelas. Numa partilha de rede onde isso não é possível, avisa no registo.

## Docker Desktop no Windows

1. Instala o **Docker Desktop** (com WSL 2) e abre-o.
2. Vê o endereço deste PC na rede de casa: *Definições → Rede e Internet → (a tua ligação) → Endereço IPv4*, ou `ipconfig`.
3. No `compose.desktop.yml`, põe esse endereço em **`PIXEL_ADDRESSES`**. Se quiseres, muda também `PIXEL_SERVER_NAME`.
4. Na pasta desse ficheiro:

   ```powershell
   docker compose -f compose.desktop.yml up -d
   ```

5. Quando o Windows perguntar, permite o Docker Desktop nas **redes privadas** (porta 8790).

O Docker Desktop corre os contentores numa máquina virtual própria, por isso o servidor não se consegue anunciar à app. Junta-o na app pelo endereço ou pelo código QR (ver [Emparelhar a app](#emparelhar-a-app)). Usa a mesma porta dos dois lados (`0.0.0.0:8790:8790` e `PIXEL_PORT`): é essa porta que vai no código QR. O `PIXEL_ADDRESSES` leva só endereços, sem porta.

A porta é publicada só em IPv4 (`0.0.0.0:`): o Docker Desktop entrega ao servidor todas as ligações a partir do seu próprio endereço, por isso a página de gestão não distingue um cliente em casa de um na internet, e em IPv6 um PC pode estar ao alcance de fora. Neste modo, só a palavra-passe protege a página (a página di-lo).

As gravações ficam na pasta `recordings` ao lado do ficheiro compose. As definições ficam num volume do Docker (`pixel-server-config`) e não numa pasta do Windows, pelo mesmo bloqueio de cima.

As gravações precisam do PC acordado. Em *Definições → Sistema → Energia*, põe "Suspender o dispositivo" em **Nunca** quando ligado à corrente.

## Linux sem Docker (systemd)

Com um só comando, que faz os passos abaixo, atualiza quando o voltas a correr e mostra no fim o endereço da página de gestão e o código de configuração:

```sh
curl -fsSL https://<site>/setup.sh | sh
```

Para o remover (os dados e as gravações ficam): `curl -fsSL https://<site>/setup.sh | sh -s -- --uninstall`. À mão:

O tarball traz o `pixel-server` e o `ffmpeg` (ambos estáticos, por isso correm em qualquer distribuição), a unidade do systemd, o ficheiro de definições, um ficheiro de serviço do Avahi, as licenças e este guia.

```sh
tar -xzf pixel-server-1.0-linux-amd64.tar.gz
sudo mkdir -p /opt/pixel-server /etc/pixel-server
sudo cp -r pixel-server-1.0-linux-amd64/* /opt/pixel-server/
sudo useradd --system --home-dir /var/lib/pixel-server --shell /usr/sbin/nologin pixelserver
sudo cp /opt/pixel-server/pixel-server.service /etc/systemd/system/
sudo install -m 600 -o root -g root /opt/pixel-server/pixel-server.env /etc/pixel-server/
sudo systemctl daemon-reload
sudo systemctl enable --now pixel-server
```

- **Definições** em `/etc/pixel-server/pixel-server.env`. Depois de mudares alguma, corre `sudo systemctl restart pixel-server`. Mantém o ficheiro legível só pelo root (o `install -m 600` de cima): pode ter o `PIXEL_ADMIN_PASSWORD` às claras.
- **Dados** em `/var/lib/pixel-server`: a lista, os aparelhos e, por omissão, as gravações.
- **Outra pasta para as gravações**: define `PIXEL_RECORDINGS` e dá a pasta ao servidor: `sudo chown pixelserver: /srv/recordings`.
- **Encontrado pela app sozinho**: o servidor anuncia-se na rede de casa (`PIXEL_MDNS`). Se preferires que seja o Avahi, define `PIXEL_MDNS=off` e copia o `pixel-server.avahi.service` para `/etc/avahi/services/pixel-server.service` — nunca os dois, ou a app mostra o servidor duas vezes.
  - Só se anuncia nos endereços de uma rede de casa (192.168.x.x, 10.x.x.x, 172.16–31.x.x, 100.64–127.x.x) e só responde a aparelhos da mesma rede. Uma máquina que ainda não tem um desses endereços (um NAS que arranca antes do router depois de uma falha de luz) é anunciada logo que o tenha; uma que só tem um endereço público (um servidor alugado) nunca é. Entretanto, o `diagnose` diz `"discovery": "waiting"`. Com `PIXEL_MDNS=on` anuncia-se em qualquer endereço.
- **Registo**: `journalctl -u pixel-server -f`.
- **Comandos** (`pair`, `reset-admin`, `diagnose`): corre-os com o utilizador do servidor, que encontra os dados do servidor em `/var/lib/pixel-server`, por exemplo `sudo -u pixelserver /opt/pixel-server/pixel-server pair`. Não leem o ficheiro de definições, por isso o `diagnose` mostra a pasta de gravações por omissão; para veres o que o serviço vê, corre-o como o serviço: `sudo systemd-run --pipe --wait --quiet -p User=pixelserver -p StateDirectory=pixel-server -p EnvironmentFile=/etc/pixel-server/pixel-server.env /opt/pixel-server/pixel-server diagnose`.

## Versões leves numa GPU

As versões leves são cópias de 360p e 540p de uma gravação, feitas enquanto grava, que começam depressa e passam em redes lentas: a app muda entre elas e o original sozinha. O Mac faz-as com o seu próprio codificador. Nos outros computadores precisam do **codificador de vídeo de uma GPU**, porque o FFmpeg do servidor não tem um codificador H.264 em software (nenhum vem com a sua licença, a LGPL). Sem ele ficam desligadas e as gravações tocam todas no original, como antes.

Ao arrancar, o servidor dá dois segundos de vídeo a cada codificador que conhece e fica com o primeiro que funciona com os fotogramas-chave onde foram pedidos (só assim as versões leves batem certo com o original):

| Onde | Codificadores testados, por ordem |
|---|---|
| Imagem Docker, `amd64` | VAAPI (Intel, AMD; cada `/dev/dri/renderD*`), Quick Sync (Intel), NVENC (NVIDIA) |
| Imagem Docker, `arm64` | nenhum (o seu FFmpeg não tem codificador de GPU) |
| Windows | NVENC (NVIDIA), AMF (AMD), o codificador da própria GPU pelo Media Foundation (Intel, Qualcomm e outras; o FFmpeg do instalador não tem Quick Sync). PCs ARM64: só o Media Foundation |

- **Intel ou AMD, Docker**: dá a GPU ao contentor, `devices: ["/dev/dri:/dev/dri"]` no ficheiro compose (`--device /dev/dri` com o `docker run`). O servidor junta-se sozinho aos grupos donos desses ficheiros de dispositivo, por isso não é preciso `group_add`. A imagem traz o controlador livre da Intel do Debian (`intel-media-va-driver`) e o runtime do Quick Sync (`libmfx-gen`: Tiger Lake, 2020, e posteriores). O único codificador H.264 desse controlador é o de baixo consumo da GPU, que o servidor experimenta primeiro em cada GPU (*vaapi (low power, …)*): Apollo Lake e Kaby Lake (2016) e posteriores; Broadwell e Skylake não têm nenhum nele. Até ao Ice Lake e ao Jasper Lake (os chips habituais dos NAS e mini-PC: Celeron J4125, N5105…), a máquina tem também de carregar o firmware HuC da GPU: acrescenta `i915.enable_guc=2` à linha de comandos do kernel e reinicia (`sudo cat /sys/kernel/debug/dri/0/gt/uc/huc_info` diz então que está a correr). Ainda não traz o controlador do Mesa para as GPUs **AMD**, por isso aparecem como *Não funciona*.
- **NVIDIA, Docker**: instala o **NVIDIA Container Toolkit** no computador e tira os comentários do bloco `deploy:` em `compose.linux.yml` (`--gpus all` com o `docker run`). A imagem pede a capacidade `video` do toolkit (`NVIDIA_DRIVER_CAPABILITIES`), que traz as bibliotecas do codificador para o contentor.
- **Tarball do systemd**: o seu `ffmpeg` é estático e só de software, por isso não usa uma GPU. Instala o FFmpeg da tua distribuição com o controlador da GPU (por exemplo `sudo apt install ffmpeg intel-media-va-driver`), define `PIXEL_FFMPEG=/usr/bin/ffmpeg` no `pixel-server.env`, deixa o utilizador do servidor abrir a GPU (`sudo usermod -aG render,video pixelserver`) e reinicia-o.
- **Windows**: basta manter o controlador da placa gráfica atualizado.

**Ler o resultado.** O ecrã **Codificador** da página de gestão lista cada codificador testado — *Funciona*, *Não funciona* (com a razão dada pelo FFmpeg), *Não serve* (codifica, mas sem os fotogramas-chave onde foram pedidos: as versões leves nunca bateriam certo), *Não está neste FFmpeg* ou *Sem dispositivo* — por cima do interruptor das versões leves, que se liga sozinho quando o codificador de uma GPU funciona. O `pixel-server diagnose` tem o mesmo em `"encoder"`: `"chosen"`, `"summary"` e `"candidates"`, cada um com o seu `"result"` e `"detail"`. O resultado fica em `probe.json` na pasta de configuração e o servidor testa outra vez sozinho quando o FFmpeg, as GPUs, os seus controladores, o kernel ou o acesso do servidor à GPU mudam (também com um `/config` reposto noutra máquina); para testar já, apaga o `probe.json` e reinicia o servidor.

**`PIXEL_RENDITIONS`**: `auto` (por omissão: ligadas quando o codificador de uma GPU funciona), `off` ou `on`. No Windows sem codificador de GPU, `on` (ou o interruptor da página de gestão) usa o codificador de software da Microsoft, que é lento e ocupa o processador. Com a variável definida, a página de gestão mostra-a mas não a muda.

Os codificadores de GPU estão configurados a partir da documentação do FFmpeg e testados aqui sem GPU. Se as versões leves de uma GPU não tocarem bem, desliga-as na página de gestão e manda-nos o resultado do `diagnose`.

## Primeira vez: a página de gestão

O servidor tem uma página web para o que o menu da app do Mac faz: emparelhar, aparelhos, limpeza automática, pausa, codificador e licenças. A página está em português ou inglês.

1. Vê o **código de configuração** no registo:

   ```sh
   docker logs pixel-server            # Docker
   journalctl -u pixel-server          # systemd
   ```

   O código está na linha `[PixelServer] admin page: http://…:8790/admin — setup code …`. Também está no ficheiro `setup-token` da pasta de configuração.
2. Abre **`http://<endereço do servidor>:8790/admin`** num browser na rede de casa.
3. Escreve o código e escolhe uma palavra-passe para a página (8 caracteres ou mais).

Esqueceste a palavra-passe? Corre isto e repete os passos 2 e 3 com o código novo:

```sh
docker exec pixel-server pixel-server reset-admin                       # Docker
sudo -u pixelserver /opt/pixel-server/pixel-server reset-admin          # systemd
```

Para não usar o código de configuração, define `PIXEL_ADMIN_PASSWORD`.

## Emparelhar a app

Na app Pixel IPTV: **Definições → Gravação → Pixel Server**.

- **Encontrado sozinho** (com a rede do host ou o systemd; não no Docker Desktop nem numa rede bridge): toca em **«Emparelhar»** ao lado do servidor.
- **Pelo endereço**: toca em **«Adicionar pelo endereço»**, escreve `192.168.1.50:8790` (o endereço e a porta do servidor) e depois o código.
- **Pelo código QR**: na página de gestão, escolhe **«Emparelhar um aparelho…»** e aponta a câmara do iPhone ou iPad para o código.

O código de emparelhamento vem da página de gestão, ou de `docker exec pixel-server pixel-server pair`. É válido durante 5 minutos.

**Dá ao servidor um endereço fixo.** No router, cria uma *reserva de DHCP* (também chamada *concessão estática* ou *reserva de endereço*) para a máquina do servidor. Senão, o router pode um dia dar-lhe outro endereço e terias de usar «Mudar endereço» na app.

## Fora de casa

Fora de casa, a app chega a um servidor no Mac pelo iCloud. Esse caminho só existe com a app do Mac. Para chegar de fora a um servidor Linux, NAS ou Windows, usa uma VPN para a rede de casa:

- **Tailscale**: instala-o na máquina do servidor e no iPhone ou iPad. Faz da máquina do servidor um *subnet router* da rede de casa (`tailscale up --advertise-routes=192.168.1.0/24`, e aprova a rota na consola do Tailscale). A app chega então ao servidor pelo endereço de casa de sempre.
- **WireGuard**: no router ou no NAS, com a mesma ideia.

Nunca reencaminhes a porta 8790 no router. O servidor fala HTTP simples. Com a rede do host (`compose.linux.yml`, systemd), a página de gestão recusa clientes fora da rede de casa; no Docker Desktop ou numa rede bridge não os consegue distinguir, e só a palavra-passe a protege.

## Atualizar

```sh
docker compose -f compose.linux.yml pull      # quando estiver publicada; até lá:
docker compose -f compose.linux.yml build --pull
docker compose -f compose.linux.yml up -d
```

Parar o contentor termina as gravações em curso de forma limpa, e elas continuam quando ele volta a arrancar. Para fixar uma versão, usa a etiqueta dela (por exemplo `pixel-server:1.0.0`) em vez de `latest`.

Com o systemd, substitui os ficheiros em `/opt/pixel-server` e corre `sudo systemctl restart pixel-server`.

## Cópias de segurança

Faz cópia do **`/config`**: a lista das gravações, os aparelhos emparelhados, a palavra-passe da página de gestão e as definições. Reposto, a app encontra o mesmo servidor sem emparelhar outra vez. As gravações são ficheiros `.ts` e `.mp4` normais na pasta das gravações: faz cópia delas como de outros vídeos.

## Definições

| Variável | Por omissão | |
|---|---|---|
| `PIXEL_SERVER_NAME` | `Pixel Server (<nome da máquina>)` | O nome que a app mostra |
| `PIXEL_PORT` | `8790` | Se outro programa a usar, o servidor não arranca |
| `PIXEL_ADDRESSES` | os desta máquina | Os endereços dados à app, separados por vírgulas: endereços IPv4 ou nomes, sem porta |
| `PIXEL_MDNS` | `auto` | O anúncio que deixa a app encontrar o servidor sozinha: `auto` (nos endereços de uma rede de casa, logo que haja um; não numa rede bridge), `on` ou `off` (`off` no Docker Desktop) |
| `PIXEL_ADMIN_PASSWORD` | (nenhuma) | A palavra-passe da página de gestão, em vez do código de configuração |
| `PIXEL_ADMIN_HOSTS` | (nenhum) | Outros nomes pelos quais a página de gestão pode ser aberta (`nas.home.arpa`) |
| `PIXEL_FFMPEG` | o incluído | Outro FFmpeg |
| `PIXEL_RENDITIONS` | `auto` | As versões leves: `auto` (quando o codificador de uma GPU funciona), `on` ou `off` — vê [Versões leves numa GPU](#versões-leves-numa-gpu) |
| `PIXEL_CONFIG`, `PIXEL_RECORDINGS` | `/config`, `/recordings` | As pastas (Docker) |
| `PUID`, `PGID` | `1000` | O utilizador e o grupo com que o servidor corre (Docker) |
| `PIXEL_ALLOW_EPHEMERAL` | (nenhum) | `1`: correr sem volumes (perde-se tudo quando o contentor é recriado) |

## Quando algo corre mal

- **"… is in the container's own storage, not a volume"**: monta `/config` e `/recordings` (`-v` ou `volumes:`). O servidor recusa-se a arrancar sem eles, porque uma atualização apagaria a lista e as gravações.
- **"PIXEL_ADDRESSES=… is not valid"**: põe só endereços (`192.168.1.50`), sem porta, `http://` nem endereços IPv6.
- **"no home network address found"** (um NAS ou um hipervisor cuja rede tem um nome invulgar): define o `PIXEL_ADDRESSES` com o endereço do servidor.
- **"cannot listen … set PIXEL_PORT"**: outro programa usa a 8790. Escolhe outra porta e junta o servidor na app nessa porta.
- **A app não encontra o servidor**: junta-o pelo endereço. No Docker Desktop, confirma o `PIXEL_ADDRESSES` e a firewall do Windows. Com a rede do host ou o systemd, confirma que a firewall deixa entrar a porta UDP 5353 (mDNS) e que o `diagnose` mostra `"discovery" : "responder"`.
- **`docker exec pixel-server pixel-server diagnose`** mostra, em JSON, o que o servidor vê: endereços, pastas, espaço livre, FFmpeg, os codificadores de GPU testados e o anúncio. Junta-o quando pedires ajuda.

## Licenças

O Pixel Server inclui o FFmpeg 8.1.3, compilado sob a **LGPL 2.1 ou posterior** sem partes GPL nem não-livres, como um programa à parte que o servidor corre. A licença, o aviso com o endereço e o SHA-256 do código-fonte, o script de compilação (`build-ffmpeg-linux.sh`) e a configuração do FFmpeg estão em `/usr/share/licenses/pixel-server` na imagem (com o `ffmpeg -version`) e em `LICENSES/` no tarball. A página de gestão também os mostra (Licenças). As licenças das bibliotecas incluídas no `pixel-server` (o SDK estático de Linux do Swift) estão em `third-party/` nesses sítios. O `ffmpeg` do tarball e o da imagem `arm64` trazem dentro a GNU C Library (glibc, LGPL 2.1 ou posterior): o aviso, com a versão exata e onde está o código-fonte, a licença e o ficheiro de copyright estão aí também (`GLIBC-NOTICE.txt`, `GLIBC-LICENSE.txt`, `GLIBC-COPYRIGHT.txt`). O `ffmpeg` da imagem `amd64` liga-se antes às bibliotecas da própria imagem — a glibc e, para as GPUs, a libva, a libdrm e a libvpl (MIT), cujos ficheiros de copyright estão em `/usr/share/doc/<pacote>/copyright` — e traz dentro os cabeçalhos de codecs da NVIDIA (MIT): `NV-CODEC-HEADERS-COPYRIGHT.txt`.
