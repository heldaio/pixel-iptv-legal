#!/bin/sh
#
#  build-ffmpeg-linux.sh — Pixel Server's own FFmpeg for Linux, from the
#  official source: the Mac's Vendor/build-ffmpeg.sh without VideoToolbox.
#
#  A minimal LGPL build (no GPL parts, no non-free parts): MPEG-TS and MP4
#  in and out, H.264 / HEVC / MPEG-2 decoding, AAC / AC-3 / MP2 audio
#  copied or re-encoded, a JPEG of a frame (the Scenes' pictures, through a
#  pipe), and the filters the light renditions and the encoder probe use
#  (scale, bwdif, color, null). Two flavours:
#    static  (the default) no external libraries, software only, fully
#            static (glibc), so the same binary runs from the systemd
#            tarball on any distribution — glibc (LGPL) is then inside it:
#            its notice (the exact Debian version, where its source is),
#            licence and copyright file go with FFmpeg's. No H.264 encoder:
#            LGPL FFmpeg has none in software, so no light renditions.
#    gpu     amd64 only, the image's: the GPUs' H.264 encoders for the
#            light renditions — VAAPI (Intel, AMD; libva, libdrm), Quick
#            Sync (Intel; libvpl) and NVENC (NVIDIA; nv-codec-headers,
#            which load the driver's own libraries at run time), and their
#            decoders (VAAPI, NVDEC). Linked against Debian trixie's glibc,
#            libva, libdrm and libvpl (all MIT but glibc), so it runs where
#            those are: the image (libva2, libva-drm2, libdrm2, libvpl2). A
#            static binary cannot load GPU drivers. No CUDA filters: nothing
#            here needs cuda_nvcc, libnpp (non-free) or cuda-llvm.
#
#  Usage: build-ffmpeg-linux.sh <amd64|arm64> <out dir> [work dir] [static|gpu]
#  Run on Debian trixie (the Dockerfile's ffmpeg stage) with gcc, make,
#  nasm, curl and xz-utils — and, for the other architecture, its cross
#  compiler and C library (gcc-x86-64-linux-gnu and libc6-dev-amd64-cross,
#  or gcc-aarch64-linux-gnu and libc6-dev-arm64-cross): the build
#  never runs under emulation. gpu: also libva-dev, libdrm-dev and
#  libvpl-dev of the target (libva-dev:amd64… with Debian's multiarch),
#  libffmpeg-nvenc-dev and pkgconf. FFMPEG_TARBALL: a copy of the source
#  already here (checked against the same SHA-256).
#  Out: ffmpeg, FFMPEG-LICENSE.txt, ffmpeg-configuration.txt; static:
#  GLIBC-NOTICE.txt, GLIBC-LICENSE.txt, GLIBC-COPYRIGHT.txt; gpu:
#  NV-CODEC-HEADERS-COPYRIGHT.txt (MIT: its code is inside ffmpeg).
#
set -eu
VERSION=8.1.3
SHA256=7138d28c96d9d3e3af4ee3d8cad72741f8ffb40da90c1112235dea3ecd3178a3
USAGE="usage: build-ffmpeg-linux.sh <amd64|arm64> <out dir> [work dir] [static|gpu]"
ARCH=${1:?$USAGE}
OUT=${2:?$USAGE}
WORK=${3:-/tmp/ffmpeg-build}
FLAVOUR=${4:-static}
mkdir -p "$OUT" "$WORK"
OUT=$(cd "$OUT" && pwd)
cd "$WORK"

case "$ARCH" in
    amd64) TRIPLE=x86_64-linux-gnu;  FFARCH=x86_64; ASM="--enable-x86asm" ;;
    arm64) TRIPLE=aarch64-linux-gnu; FFARCH=aarch64; ASM="--disable-x86asm" ;;
    *) echo "unknown architecture: $ARCH (amd64 or arm64)" >&2; exit 2 ;;
esac
case "$FLAVOUR" in
    static) ;;
    gpu) [ "$ARCH" = amd64 ] || { echo "the gpu flavour is amd64 only" >&2; exit 2; } ;;
    *) echo "unknown flavour: $FLAVOUR (static or gpu)" >&2; exit 2 ;;
esac
# The machine's own compiler for its own architecture, else the cross one
# — and the C library linked in, from that one's package.
if [ "$(gcc -dumpmachine)" = "$TRIPLE" ]; then
    CROSS=""
    LIBC_PKG=libc6-dev
else
    CROSS="--enable-cross-compile --cross-prefix=$TRIPLE- --target-os=linux"
    LIBC_PKG=libc6-dev-$ARCH-cross
fi
LIBC_VERSION=$(dpkg-query -W -f='${Version}' "$LIBC_PKG")
LIBC_SOURCE=$(dpkg-query -W -f='${source:Package} ${source:Version}' "$LIBC_PKG")

TARBALL="ffmpeg-$VERSION.tar.xz"
if [ -n "${FFMPEG_TARBALL:-}" ]; then
    cp "$FFMPEG_TARBALL" "$TARBALL"
elif [ ! -f "$TARBALL" ]; then
    curl -fLO "https://ffmpeg.org/releases/$TARBALL"
fi
echo "$SHA256  $TARBALL" | sha256sum -c -
rm -rf "ffmpeg-$VERSION"
tar -xJf "$TARBALL"
cd "ffmpeg-$VERSION"

if [ "$FLAVOUR" = static ]; then
    LINK='--extra-ldflags=-static --pkg-config-flags=--static'
    GPU=""
else
    # The target's .pc files (Debian's multiarch folders), with the
    # machine's own pkg-config.
    export PKG_CONFIG_LIBDIR="/usr/lib/$TRIPLE/pkgconfig:/usr/share/pkgconfig:/usr/lib/pkgconfig"
    LINK="--pkg-config=pkg-config"
    GPU="--enable-vaapi --enable-libdrm --enable-libvpl --enable-ffnvcodec --enable-nvenc --enable-nvdec
         --enable-encoder=h264_vaapi,h264_qsv,h264_nvenc
         --enable-hwaccel=h264_vaapi,hevc_vaapi,mpeg2_vaapi,h264_nvdec,hevc_nvdec,mpeg2_nvdec
         --enable-filter=hwupload,hwdownload"
fi

# shellcheck disable=SC2086
./configure \
    --prefix="$WORK/out" \
    --arch="$FFARCH" $CROSS \
    --extra-cflags="-O2" \
    $LINK \
    --disable-everything --disable-shared --enable-static \
    --disable-gpl --disable-nonfree --disable-doc --disable-debug \
    $ASM --disable-network --disable-autodetect \
    --disable-ffplay --disable-ffprobe --enable-ffmpeg \
    --enable-protocol=file,pipe \
    --enable-demuxer=mpegts,mov \
    --enable-muxer=mpegts,mp4,image2pipe,null \
    --enable-parser=h264,hevc,aac,aac_latm,ac3,mpegaudio,mpegvideo \
    --enable-decoder=h264,hevc,mpeg2video,aac,aac_latm,ac3,eac3,mp2,mp3 \
    --enable-encoder=aac,mjpeg,rawvideo,wrapped_avframe \
    --enable-filter=scale,format,null,anull,aformat,aresample,setpts,fps,bwdif,color \
    --enable-bsf=h264_mp4toannexb,hevc_mp4toannexb,extract_extradata,aac_adtstoasc,null \
    --enable-indev=lavfi \
    --enable-swscale --enable-swresample --enable-avfilter --enable-avdevice \
    $GPU \
    > "$WORK/configure.log" 2>&1 || { cat "$WORK/configure.log"; tail -40 ffbuild/config.log; exit 1; }
cat "$WORK/configure.log"

# LGPL or nothing: a configure that went GPL or non-free must never ship.
LICENSE=$(sed -n 's/^#define FFMPEG_LICENSE "\(.*\)"$/\1/p' config.h)
echo "FFmpeg license: $LICENSE"
[ "$LICENSE" = "LGPL version 2.1 or later" ] || { echo "not LGPL 2.1+: $LICENSE" >&2; exit 1; }

make -j"$(nproc)"
${CROSS:+$TRIPLE-}strip -o "$OUT/ffmpeg" ffmpeg
chmod +x "$OUT/ffmpeg"
cp COPYING.LGPLv2.1 "$OUT/FFMPEG-LICENSE.txt"
{
    echo "FFmpeg $VERSION — https://ffmpeg.org/releases/$TARBALL"
    echo "SHA-256: $SHA256"
    echo "Architecture: $ARCH ($TRIPLE)"
    echo "License: $LICENSE"
    echo "Configuration: $(sed -n 's/^#define FFMPEG_CONFIGURATION "\(.*\)"$/\1/p' config.h)"
    if [ "$FLAVOUR" = static ]; then
        echo "C library: glibc, linked statically — Debian $LIBC_PKG $LIBC_VERSION (source package $LIBC_SOURCE)"
    else
        echo "Linked dynamically with Debian trixie's glibc, libva, libva-drm, libdrm and libvpl (the image's packages;"
        echo "their copyright files are in /usr/share/doc/<package>/copyright there)."
        echo "nv-codec-headers: Debian libffmpeg-nvenc-dev $(dpkg-query -W -f='${Version}' libffmpeg-nvenc-dev) (MIT,"
        echo "see NV-CODEC-HEADERS-COPYRIGHT.txt); NVIDIA's driver libraries are loaded at run time from the host."
    fi
} > "$OUT/ffmpeg-configuration.txt"

if [ "$FLAVOUR" = gpu ]; then
    cp /usr/share/doc/libffmpeg-nvenc-dev/copyright "$OUT/NV-CODEC-HEADERS-COPYRIGHT.txt"
    cat "$OUT/ffmpeg-configuration.txt"
    ls -la "$OUT/ffmpeg"
    exit 0
fi

# glibc, inside ffmpeg: LGPL 2.1 or later. Its Debian copyright file (the
# cross package's, or the native libc6's), the licence text, and a notice
# with the exact version and where its source is.
SRC_NAME=${LIBC_SOURCE% *}
SRC_VERSION=${LIBC_SOURCE#* }
# The cross packages' version is glibc's with "cross<n>" after it; their
# source package (cross-toolchain-base) holds glibc's source.
GLIBC_VERSION=${LIBC_VERSION%cross*}
COPYRIGHT=""
for f in "/usr/share/doc/$LIBC_PKG/copyright" "/usr/share/doc/${LIBC_PKG%-dev*}/copyright" /usr/share/doc/libc6/copyright \
         /usr/share/doc/libc6-dev/copyright; do
    if [ -f "$f" ]; then COPYRIGHT=$f; break; fi
done
[ -n "$COPYRIGHT" ] || { echo "no copyright file for $LIBC_PKG" >&2; exit 1; }
cp "$COPYRIGHT" "$OUT/GLIBC-COPYRIGHT.txt"
cp /usr/share/common-licenses/LGPL-2.1 "$OUT/GLIBC-LICENSE.txt"
cat > "$OUT/GLIBC-NOTICE.txt" <<NOTICE
The ffmpeg program in this release is linked statically with the GNU C
Library (glibc, https://www.gnu.org/software/libc/), licensed under the
GNU Lesser General Public License version 2.1 or later (see
GLIBC-LICENSE.txt; its copyright notices are in GLIBC-COPYRIGHT.txt).

Version: glibc $GLIBC_VERSION — Debian package $LIBC_PKG $LIBC_VERSION
(source package $SRC_NAME $SRC_VERSION), for $TRIPLE.
Source code: https://snapshot.debian.org/package/$SRC_NAME/$SRC_VERSION/
  (also https://sources.debian.org/src/$SRC_NAME/$SRC_VERSION/)

To link ffmpeg with another or a modified glibc, build it again from
FFmpeg's source with build-ffmpeg-linux.sh (see FFMPEG-NOTICE.txt). On
request we will send a copy of this glibc source code, at no more than
the cost of sending it, for three years from the date of this release.
NOTICE
cat "$OUT/GLIBC-NOTICE.txt"
cat "$OUT/ffmpeg-configuration.txt"
ls -la "$OUT/ffmpeg"
