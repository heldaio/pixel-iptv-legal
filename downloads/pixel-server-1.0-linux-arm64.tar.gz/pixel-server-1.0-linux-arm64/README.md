# Pixel Server for Linux, NAS and Windows

Pixel Server records TV programmes for the **Pixel IPTV** app. You schedule a recording in the app. The server records it and keeps it, and every iPhone, iPad and Apple TV at home plays it from there.

On a Mac, Pixel Server is a menu-bar app. This folder covers every other machine:

| Where | How | File |
|---|---|---|
| Linux PC or server, NAS (Synology, QNAP, Unraid…) | Docker | `compose.linux.yml` |
| Windows 10 or 11 PC | installer (a Windows service) | `PixelServer-<version>-windows-<arch>.exe` — see `Windows/README.md` |
| Windows PC (or a Mac without the Mac app) | Docker Desktop | `compose.desktop.yml` |
| Linux without Docker | systemd service | `pixel-server-<version>-linux-<arch>.tar.gz` |

The machine must be on when a recording is due. The server works on the **home network** only (see [Away from home](#away-from-home)).

A Portuguese version of this guide is in [LEIA-ME.md](LEIA-ME.md).

---

## The image

Until the image is published, build it from the `PixelServer` folder (the one that contains `Docker/`):

```sh
docker build -f Docker/Dockerfile -t pixel-server:latest .
```

Building needs BuildKit, which Docker has used by default since version 23 (the Dockerfile's first line fetches the Dockerfile syntax it needs, so an older built-in one is fine). The compose files can also build it (`docker compose -f Docker/compose.linux.yml build`). The image is for `linux/amd64` (Intel and AMD) and `linux/arm64` (Raspberry Pi 4/5, most ARM NAS units). It holds the server and its own FFmpeg, which the server uses for the Scenes pictures and, on `amd64`, for the light versions on a GPU (see [Light versions on a GPU](#light-versions-on-a-gpu)).

## Docker on Linux or a NAS

1. Copy `compose.linux.yml` to a folder of its own, for example `~/pixel-server`.
2. Edit it:
   - **`PUID` / `PGID`**: the user and group the server runs as. Use the owner of the recordings folder (run `id` as that user). On a Synology, use your own user's (`id` over SSH).
   - **`TZ`**: your time zone, so the log shows local times.
   - **`volumes`**: `/config` holds the list of recordings, the paired devices and the admin page password. Keep it on a **local disk**, never on a network share (CIFS/SMB, NFS): the lock that stops two servers recording the same programme does not hold there. `/recordings` can be any folder, a NAS share included.
3. Start it:

   ```sh
   docker compose -f compose.linux.yml up -d
   ```

The file uses `network_mode: host`, so the server sees the home network's address and the app can reach it there. With Docker's default bridge network, the server sees only Docker's own addresses (172.17.x.x). If you must use a bridge, do as on Docker Desktop: publish the port on IPv4 only (`"0.0.0.0:8790:8790"`) and set `PIXEL_ADDRESSES`. On a bridge, Docker hands the server every connection from its own address, so the admin page cannot tell a client at home from one elsewhere: only its password protects it (the page says so).

**NAS notes**
- **Synology** (Container Manager): *Project → Create*, paste `compose.linux.yml`, and set the volumes to folders under `/volume1/docker/pixel-server/…`.
- **QNAP** (Container Station): *Applications → Create* with the same file.
- **Unraid**: use the Compose Manager plugin with the same file. `PUID=99` and `PGID=100` are Unraid's usual owner of shares.

The server never runs as root. At start it gives `/config` and `/recordings` themselves (not the files inside `/recordings`) to `PUID:PGID` if that user cannot write to them. On a network share where that is not possible, it says so in the log.

## Docker Desktop on Windows

1. Install **Docker Desktop** (with WSL 2) and start it.
2. Find this PC's address on the home network: *Settings → Network & internet → (your connection) → IPv4 address*, or `ipconfig`.
3. In `compose.desktop.yml`, set **`PIXEL_ADDRESSES`** to that address. Optionally set `PIXEL_SERVER_NAME`.
4. In that file's folder:

   ```powershell
   docker compose -f compose.desktop.yml up -d
   ```

5. When Windows asks, allow Docker Desktop on **private networks** (port 8790).

Docker Desktop runs containers in a virtual machine of its own, so the server cannot announce itself to the app. Add it in the app by address or by QR code (see [Pairing the app](#pairing-the-app)). Use the same port on both sides (`0.0.0.0:8790:8790` and `PIXEL_PORT`): that port goes into the QR code. `PIXEL_ADDRESSES` takes addresses only, without a port.

The port is published on IPv4 only (`0.0.0.0:`): Docker Desktop hands the server every connection from its own address, so the admin page cannot tell a client at home from one on the internet, and on IPv6 a PC can be reachable from outside. Only the password protects the page in this mode (the page says so).

The recordings go to the `recordings` folder next to the compose file. The settings go to a Docker volume (`pixel-server-config`) rather than a Windows folder, for the same lock as above.

Recordings need the PC to stay awake. In *Settings → System → Power*, set "Make my device sleep" to **Never** while plugged in.

## Linux without Docker (systemd)

In one command, which does the steps below, updates when run again and shows the admin page’s address and the setup code at the end:

```sh
curl -fsSL https://<site>/setup.sh | sh
```

To remove it (the data and recordings stay): `curl -fsSL https://<site>/setup.sh | sh -s -- --uninstall`. By hand:

The tarball holds `pixel-server` and `ffmpeg` (both static, so they run on any distribution), the systemd unit, its settings file, an Avahi service file, the licences and this guide.

```sh
tar -xzf pixel-server-1.0-linux-amd64.tar.gz
sudo mkdir -p /opt/pixel-server /etc/pixel-server
sudo cp -r pixel-server-1.0-linux-amd64/* /opt/pixel-server/
sudo useradd --system --home-dir /var/lib/pixel-server --shell /usr/sbin/nologin pixelserver
sudo cp /opt/pixel-server/pixel-server.service /etc/systemd/system/
sudo install -m 600 -o root -g root /opt/pixel-server/pixel-server.env /etc/pixel-server/
sudo systemctl daemon-reload
sudo systemctl enable --now pixel-server
```

- **Settings** are in `/etc/pixel-server/pixel-server.env`. Run `sudo systemctl restart pixel-server` after a change. Keep the file readable by root only (`install -m 600` above): it can hold `PIXEL_ADMIN_PASSWORD` in clear.
- **Data** is in `/var/lib/pixel-server`: the list, the devices and, by default, the recordings.
- **Another recordings folder**: set `PIXEL_RECORDINGS` and give the folder to the server: `sudo chown pixelserver: /srv/recordings`.
- **Found by the app on its own**: the server announces itself on the home network (`PIXEL_MDNS`). If you would rather Avahi did it, set `PIXEL_MDNS=off` and copy `pixel-server.avahi.service` to `/etc/avahi/services/pixel-server.service` — never both, or the app lists the server twice.
  - It announces only on a home network's addresses (192.168.x.x, 10.x.x.x, 172.16–31.x.x, 100.64–127.x.x) and answers only devices on the same network. A machine with no such address yet (a NAS up before the router after a power cut) is announced as soon as it has one; one with only a public address (a rented server) is never announced. `diagnose` says `"discovery": "waiting"` meanwhile. `PIXEL_MDNS=on` announces on any address.
- **Log**: `journalctl -u pixel-server -f`.
- **Commands** (`pair`, `reset-admin`, `diagnose`) run as the server's user, which finds the server's data in `/var/lib/pixel-server`: for example `sudo -u pixelserver /opt/pixel-server/pixel-server pair`. They do not read the settings file, so `diagnose` shows the default recordings folder; to see what the service sees, run it the way the service does: `sudo systemd-run --pipe --wait --quiet -p User=pixelserver -p StateDirectory=pixel-server -p EnvironmentFile=/etc/pixel-server/pixel-server.env /opt/pixel-server/pixel-server diagnose`.

## Light versions on a GPU

The light versions are 360p and 540p copies of a recording, made while it records, that start quickly and play on a slow network: the app moves between them and the original by itself. The Mac makes them with its own encoder. Anywhere else they need a **GPU's video encoder**, because the server's FFmpeg has no H.264 encoder in software (none comes under its licence, the LGPL). Without one they stay off and every recording plays in the original, as before.

At start, the server gives each encoder it knows two seconds of video and keeps the first that works with its key frames where they were asked for (only then do the light versions line up with the original):

| Where | Encoders tried, in order |
|---|---|
| Docker image, `amd64` | VAAPI (Intel, AMD; each `/dev/dri/renderD*`), Quick Sync (Intel), NVENC (NVIDIA) |
| Docker image, `arm64` | none (its FFmpeg has no GPU encoder) |
| Windows | NVENC (NVIDIA), AMF (AMD), the GPU's own encoder through Media Foundation (Intel, Qualcomm and others; the installer's FFmpeg has no Quick Sync). ARM64 PCs: Media Foundation only |

- **Intel or AMD, Docker**: give the container the GPU, `devices: ["/dev/dri:/dev/dri"]` in the compose file (`--device /dev/dri` with `docker run`). The server joins the groups that own those device files by itself, so no `group_add` is needed. The image has Debian's free Intel driver (`intel-media-va-driver`) and Quick Sync runtime (`libmfx-gen`: Tiger Lake, 2020, and later). That driver's only H.264 encoder is the GPU's low-power one, which the server tries first on each GPU (*vaapi (low power, …)*): Apollo Lake and Kaby Lake (2016) and later; Broadwell and Skylake have none in it. Up to Ice Lake and Jasper Lake (the usual NAS and mini-PC chips: Celeron J4125, N5105…), the host must also load the GPU's HuC firmware: add `i915.enable_guc=2` to the kernel's command line and reboot (`sudo cat /sys/kernel/debug/dri/0/gt/uc/huc_info` then says it is running). It does not have Mesa's driver for **AMD** GPUs yet, so they show as *Doesn't work*.
- **NVIDIA, Docker**: install the **NVIDIA Container Toolkit** on the host, then uncomment the `deploy:` block in `compose.linux.yml` (`--gpus all` with `docker run`). The image asks for the toolkit's `video` capability (`NVIDIA_DRIVER_CAPABILITIES`), which brings the encoder's libraries into the container.
- **systemd tarball**: its `ffmpeg` is static and software only, so it cannot use a GPU. Install your distribution's FFmpeg with the GPU's driver (for example `sudo apt install ffmpeg intel-media-va-driver`), set `PIXEL_FFMPEG=/usr/bin/ffmpeg` in `pixel-server.env`, let the server's user open the GPU (`sudo usermod -aG render,video pixelserver`) and restart it.
- **Windows**: nothing to do but keep the graphics driver up to date.

**Reading the result.** The admin page's **Encoder** screen lists every encoder tried — *Works*, *Doesn't work* (with FFmpeg's reason), *Not usable* (it encodes, but not with its key frames where asked: the light versions would never line up), *Not in this FFmpeg* or *No device* — above the light versions switch, which is on by itself when a GPU's encoder works. `pixel-server diagnose` has the same under `"encoder"`: `"chosen"`, `"summary"` and `"candidates"`, each with its `"result"` and `"detail"`. The result is kept in `probe.json` in the config folder and the server tries again by itself when FFmpeg, the GPUs, their drivers, the kernel or the server's access to the GPU change (a `/config` restored on another machine too); to try again anyway, delete `probe.json` and restart the server.

**`PIXEL_RENDITIONS`**: `auto` (the default: on when a GPU's encoder works), `off`, or `on`. On Windows with no GPU encoder, `on` (or the admin page's switch) uses Microsoft's software encoder, which is slow and keeps the processor busy. When the variable is set, the admin page shows it and cannot change it.

The GPU encoders are set up from FFmpeg's documentation and tested here without a GPU. If a GPU's light versions do not play well, turn them off on the admin page and send us the `diagnose` output.

## First run: the admin page

The server has a web page for what the Mac app's menu does: pairing, devices, automatic clean-up, pause, the encoder and the licences. The page is in Portuguese or English.

1. Get the **setup code** from the log:

   ```sh
   docker logs pixel-server            # Docker
   journalctl -u pixel-server          # systemd
   ```

   The code is on the `[PixelServer] admin page: http://…:8790/admin — setup code …` line. It is also in the `setup-token` file in the config folder.
2. Open **`http://<server address>:8790/admin`** in a browser on the home network.
3. Type the code, then choose a password for the page (8 characters or more).

Forgot the password? Run this, then repeat steps 2 and 3 with the new code:

```sh
docker exec pixel-server pixel-server reset-admin                       # Docker
sudo -u pixelserver /opt/pixel-server/pixel-server reset-admin          # systemd
```

To skip the setup code, set `PIXEL_ADMIN_PASSWORD`.

## Pairing the app

In the Pixel IPTV app: **Settings → Recording → Pixel Server**.

- **Found on its own** (host networking or systemd; not Docker Desktop or a bridge network): tap **«Emparelhar» / "Pair"** next to the server.
- **By address**: tap **«Adicionar pelo endereço» / "Add by address"**, type `192.168.1.50:8790` (the server's address and port), then the code.
- **By QR code**: on the admin page, choose **«Emparelhar um aparelho…» / "Pair a device…"** and point the iPhone or iPad camera at the code.

The pairing code comes from the admin page, or from `docker exec pixel-server pixel-server pair`. It is valid for 5 minutes.

**Give the server a fixed address.** In the router, create a *DHCP reservation* (also called *static lease* or *address reservation*) for the server's machine. Otherwise the router may give it another address one day, and you would have to use «Mudar endereço» / "Change address" in the app.

## Away from home

Away from home, the app reaches a Mac server through iCloud. That route exists only with the Mac app. To reach a Linux, NAS or Windows server from outside, use a VPN to your home network:

- **Tailscale**: install it on the server's machine and on the iPhone or iPad. Make the server's machine a *subnet router* for the home network (`tailscale up --advertise-routes=192.168.1.0/24`, then approve the route in the Tailscale admin console). The app then reaches the server at its usual home address.
- **WireGuard**: on the router or the NAS, with the same idea.

Never forward port 8790 on the router. The server speaks plain HTTP. With host networking (`compose.linux.yml`, systemd) the admin page refuses clients outside the home network; on Docker Desktop or a bridge network it cannot tell them apart, and only its password protects it.

## Updating

```sh
docker compose -f compose.linux.yml pull      # once published; until then:
docker compose -f compose.linux.yml build --pull
docker compose -f compose.linux.yml up -d
```

Stopping the container stops the recordings cleanly, and they carry on when it starts again. To pin a version, use its tag (for example `pixel-server:1.0.0`) instead of `latest`.

With systemd, replace the files in `/opt/pixel-server` and run `sudo systemctl restart pixel-server`.

## Backups

Back up **`/config`**: the list of recordings, the paired devices, the admin page password and the settings. Restored, the app finds the same server with no pairing again. The recordings are plain `.ts` and `.mp4` files in the recordings folder: back them up like any other video files.

## Settings

| Variable | Default | |
|---|---|---|
| `PIXEL_SERVER_NAME` | `Pixel Server (<host name>)` | The name the app shows |
| `PIXEL_PORT` | `8790` | If another program has it, the server does not start |
| `PIXEL_ADDRESSES` | this machine's own | The addresses the app is given, comma-separated: IPv4 addresses or names, no port |
| `PIXEL_MDNS` | `auto` | The announcement that lets the app find the server on its own: `auto` (on a home network's addresses, once there is one; not on a bridge network), `on` or `off` (`off` under Docker Desktop) |
| `PIXEL_ADMIN_PASSWORD` | (none) | The admin page password, instead of the setup code |
| `PIXEL_ADMIN_HOSTS` | (none) | Extra names the admin page may be opened by (`nas.home.arpa`) |
| `PIXEL_FFMPEG` | the bundled one | Another FFmpeg |
| `PIXEL_RENDITIONS` | `auto` | The light versions: `auto` (when a GPU's encoder works), `on` or `off` — see [Light versions on a GPU](#light-versions-on-a-gpu) |
| `PIXEL_CONFIG`, `PIXEL_RECORDINGS` | `/config`, `/recordings` | The folders (Docker) |
| `PUID`, `PGID` | `1000` | The user and group the server runs as (Docker) |
| `PIXEL_ALLOW_EPHEMERAL` | (none) | `1`: run without volumes (everything is lost when the container is recreated) |

## When something is wrong

- **"… is in the container's own storage, not a volume"**: mount `/config` and `/recordings` (`-v` or `volumes:`). The server refuses to start without them, because an update would erase the list and the recordings.
- **"PIXEL_ADDRESSES=… is not valid"**: give addresses only (`192.168.1.50`), without a port, `http://` or an IPv6 address.
- **"no home network address found"** (a NAS or a hypervisor whose network has an unusual name): set `PIXEL_ADDRESSES` to the server's address.
- **"cannot listen … set PIXEL_PORT"**: another program uses 8790. Choose another port, and add the server in the app at that port.
- **The app does not find the server**: add it by address. On Docker Desktop, check `PIXEL_ADDRESSES` and the Windows firewall. With host networking or systemd, check that the firewall lets UDP port 5353 (mDNS) in, and that `diagnose` shows `"discovery" : "responder"`.
- **`docker exec pixel-server pixel-server diagnose`** prints, as JSON, what the server sees: addresses, folders, free space, FFmpeg, the GPU encoders tried and the announcement. Include it when asking for help.

## Licences

Pixel Server includes FFmpeg 8.1.3, built under the **LGPL 2.1 or later** with no GPL or non-free parts, as a separate program that the server runs. The licence, the notice with the source code's address and SHA-256, the build script (`build-ffmpeg-linux.sh`) and FFmpeg's configuration are in `/usr/share/licenses/pixel-server` in the image (with `ffmpeg -version`) and in `LICENSES/` in the tarball. The admin page shows them too (Licences). The licences of the libraries built into `pixel-server` (Swift's static Linux SDK) are in `third-party/` there. The tarball's `ffmpeg` and the `arm64` image's have the GNU C Library (glibc, LGPL 2.1 or later) inside: its notice, with the exact version and where its source is, its licence and its copyright file are there too (`GLIBC-NOTICE.txt`, `GLIBC-LICENSE.txt`, `GLIBC-COPYRIGHT.txt`). The `amd64` image's `ffmpeg` is linked instead with the image's own libraries — glibc, and for the GPUs libva, libdrm and libvpl (MIT), whose copyright files are in `/usr/share/doc/<package>/copyright` — and has NVIDIA's codec headers (MIT) inside: `NV-CODEC-HEADERS-COPYRIGHT.txt`.
